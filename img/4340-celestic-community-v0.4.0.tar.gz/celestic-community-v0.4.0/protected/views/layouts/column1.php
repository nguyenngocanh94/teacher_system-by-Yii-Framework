<?php $this->beginContent('application.views.layouts.main'); ?>
<div class="container rounded">
	<?php echo $content; ?>
</div>
<?php $this->endContent(); ?>