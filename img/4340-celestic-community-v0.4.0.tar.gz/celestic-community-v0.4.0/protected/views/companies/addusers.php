<h3 style="margin-top:10px">Add Users</h3>
<?php echo $this->renderPartial('_addUsers', array('model'=>$model, 'users'=>$users)); ?>