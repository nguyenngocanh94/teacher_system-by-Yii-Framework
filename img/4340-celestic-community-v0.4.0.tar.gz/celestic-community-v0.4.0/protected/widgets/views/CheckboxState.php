<p class="field switch" id="<?php echo $this->elementId; ?>">
    <label for="radio1" class="cb-enable <?php echo ($this->state == true) ? "selected" : ""; ?>"><span>Enable</span></label>
    <label for="radio2" class="cb-disable <?php echo ($this->state == false) ? "selected" : ""; ?>"><span>Disable</span></label>
</p>