<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	'pending' => 'Ausstehend',
	'revised' => 'Zu überarbeiten',
	'cancelled' => 'Abgebrochen',
	'accepted' => 'Angenommen',
	'closed' => 'Geschlossen',
	'totest' => 'Zu prüfen',
	'inprogress' => 'In Bearbeitung',
);
?>
