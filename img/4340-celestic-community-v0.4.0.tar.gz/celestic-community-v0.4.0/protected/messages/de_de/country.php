<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	// MODEL
	'country_id' => 'Land',
	'country_name' => 'Land',
	'country_continent' => 'Kontinent',
	'country_region' => 'Regionn',
);
?>
