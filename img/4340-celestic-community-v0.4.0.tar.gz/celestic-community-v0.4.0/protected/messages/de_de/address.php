<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	// MODEL
	'address_id' => 'Adresse',
	'address_text' => 'Adresse',
	'address_postalCode' => 'Postleitzahl',
	'address_phone' => 'Telefon',
	'address_web' => 'Website',
	'city_id' => 'Ort',
	// FORMS
	'FormAddressText' => 'Adresse festlegen',
	'FormAddressPostalCode' => 'Postleitzahl festlegen',
	'FormAddressPhone' => 'Telefonnummer',
	'FormAddressWeb' => 'Meine URL',
	'FormAddressCity' => 'Ort, in dem der Benutzer wohnt',
	'FormDragMark' => 'Adresse markieren',
	// FIELDS
	'selectOption' => 'Eine Option auswählen',
);
?>
