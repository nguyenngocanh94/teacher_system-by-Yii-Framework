<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	'project_id' => 'Projekt',
	'user_id' => 'Benutzer',
	'client_id' => 'Kunden',
);
?>
