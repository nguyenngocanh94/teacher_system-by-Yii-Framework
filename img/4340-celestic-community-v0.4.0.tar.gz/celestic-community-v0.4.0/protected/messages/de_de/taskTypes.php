<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	'Suggestion' => 'Vorschlag',
	'Error' => 'Fehler',
	'Addition' => 'Ergänzung',
	'Maintenance' => 'Wartung',
	'Improvement' => 'Verbesserung',
	'Modification' => 'Änderung',
	'Planning' => 'Planung',
	'Testing' => 'Prüfung',
);
?>
