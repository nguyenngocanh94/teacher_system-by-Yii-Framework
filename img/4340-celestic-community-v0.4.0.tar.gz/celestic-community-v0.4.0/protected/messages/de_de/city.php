<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	// MODEL
	'city_id' => 'Ort',
	'city_name' => 'Ort',
	'city_code' => 'Vorwahl',
	'city_district' => 'Stadtteil',
	'city_population' => 'Stadtbevölkerung',
	'country_id' => 'Land',
);
?>
