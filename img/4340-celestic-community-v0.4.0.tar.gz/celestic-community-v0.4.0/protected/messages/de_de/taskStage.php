<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	'analysis' => 'Analyse',
	'design' => 'Gestaltung',
	'development' => 'Entwicklung',
	'testing' => 'Prüfung',
	'documentation' => 'Dokumentation',
	'evolution' => 'Entstehung',
	'finalization' => 'Fertigstellung',
);
?>
