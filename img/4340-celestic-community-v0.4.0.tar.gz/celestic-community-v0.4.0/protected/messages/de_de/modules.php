<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	'all' => 'Alle',
	'budgets' => 'Budgets',
	'budgetsconcepts' => 'Budgetkonzept',
	'invoices' => 'Rechnungen',
	'invoicesconcepts' => 'Rechnungskonzept',
	'expenses' => 'Ausgaben',
	'expensesconcepts' => 'Ausgabenkonzept',
	'bconcepts' => 'Budgetkonzept',
	'iconcepts' => 'Rechnungskonzept',
	'econcepts' => 'Ausgabenkonzept',
	'documents' => 'Dokumente',
	'milestones' => 'Meilensteine',
	'diagrams' => 'Diagramme',
	'cases' => 'Fälle',
	'tasks' => 'Aufgaben',
	'projects' => 'Projekte',
	'companies' => 'Firmen',
	'users' => 'Benutzer',
	'clients' => 'Kunden',
	'dashboards' => 'Dashboard',
	'validations' => 'Validierungen',
	'secuences' => 'Abfolgen',
	'configuration' => 'Konfiguration',
	'dashboard' => 'Dashboard',
);
?>
