<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	// FORMS
	'TitleDiagram' => 'Diagramm',
	// FIELDS
	'FieldCreateDiagram' => 'Erstellen',
);
?>
