<?php
/*
Translation: IST planbar GmbH - http://www.istplanbar.de
10-11-2011
*/
return array(
	// VIEWS
	'CalendarTitle' => 'Kalnderveranstaltungen',
	'UpcomingMilestonesTitle' => 'Anstehende Meilensteine',
	'ProjectsProgressTitle' => 'Projektfortschritt',
	'OverdueMilestonesTitle' => 'Überfällige Meilensteine',
	'MyProjectsTitle' => 'Meine Projekte',
	'RecentActivityTitle' => 'Neueste Aktivitäten',
	'TasksToDoTitle' => 'Aufgaben',
	'InvoicesStatisticsTitle' => 'Rechnungsstatistiken',
	'HelpResourcesTitle' => 'Aufgabenstatus',
	'EmailNotificationsTitle' => 'E-Mail-Benachrichtigungen',
	'RecentDocumentsTitle' => 'Neueste Dokumente',
	'EffortDistribution' => 'Aufwandsverteilung',
	'ViewAll' => 'Alle ansehen',
);
?>
