<?php
return array(
	// MODEL
	'city_id' => 'Ciudad',
	'city_name' => 'Nombre de la Ciudad',
	'city_code' => 'C&oacute;digo de la Ciudad',
	'city_district' => 'Distrito',
	'city_population' => 'Poblaci&oacute;n',
	'country_id' => 'Pa&iacute;s',
);
?>