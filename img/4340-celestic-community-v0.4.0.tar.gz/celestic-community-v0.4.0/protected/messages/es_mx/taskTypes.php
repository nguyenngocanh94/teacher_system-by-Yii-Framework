<?php
return array(
	'Suggestion' => 'Sugerencia',
	'Error' => 'Error',
	'Addition' => 'Adicion',
	'Maintenance' => 'Mantenimiento',
	'Improvement' => 'Mejora',
	'Modification' => 'Modificacion',
	'Planning' => 'Planeacion',
	'Testing' => 'Pruebas',
);
?>