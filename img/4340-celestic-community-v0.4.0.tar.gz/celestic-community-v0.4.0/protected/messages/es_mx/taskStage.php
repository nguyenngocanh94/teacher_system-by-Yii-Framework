<?php
return array(
	'analysis' => 'Analisis',
	'design' => 'Diseno',
	'development' => 'Desarrollo',
	'testing' => 'Pruebas',
	'documentation' => 'Documentacion',
	'evolution' => 'Evolucion',
	'finalization' => 'Finalizacion',
);
?>