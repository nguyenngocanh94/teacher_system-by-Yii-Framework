<?php
return array(
	'pending' => 'Pendiente',
	'revised' => 'Por Revisar',
	'cancelled' => 'Cancelado',
	'accepted' => 'Aceptado',
	'closed' => 'Cerrado',
	'totest' => 'Por Probar',
	'inprogress' => 'En Progreso',
);
?>