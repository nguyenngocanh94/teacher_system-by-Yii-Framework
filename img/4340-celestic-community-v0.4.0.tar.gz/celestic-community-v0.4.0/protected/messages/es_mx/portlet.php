<?php
return array(
	// VIEWS
	'CalendarTitle' => 'Calendario de Eventos',
	'UpcomingMilestonesTitle' => 'Hitos Pr&oacute;ximos',
	'ProjectsProgressTitle' => 'Avance de los Proyectos',
	'OverdueMilestonesTitle' => 'Hitos Atrasados',
	'MyProjectsTitle' => 'Mis Proyectos',
	'RecentActivityTitle' => 'Actividad Reciente',
	'TasksToDoTitle' => 'Tareas pendientes',
	'InvoicesStatisticsTitle' => 'Facturaci&oacute;n',
	'HelpResourcesTitle' => 'Estado de tareas',
	'EmailNotificationsTitle' => 'Notificaciones',
	'RecentDocumentsTitle' => 'Documentos Recientes',
	'EffortDistribution' => 'Distribuci&oacute;n del esfuerzo',
	'ViewAll' => 'Ver Todos',
);
?>