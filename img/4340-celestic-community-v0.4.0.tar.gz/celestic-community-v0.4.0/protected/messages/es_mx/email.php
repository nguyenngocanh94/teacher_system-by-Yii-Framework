<?php
return array(
	'CommentPosted' => 'Comentario escrito',
	'BudgetStatusChange' => 'Cambio de estatus en presupuesto',
	'BudgetValidationRequest' => 'Peticion de validacion de presupuesto',
	'CaseStatusChange' => 'Cambio de estatus en caso',
	'TaskAssigned' => 'Asignacion de tarea',
	'TaskStatusChanged' => 'Cambio de estatus de Tarea',
	'UserInvitation' => 'Invitacion para participar en Celestic',
	'PasswordReset' => 'Notificacion de cambio de clave de acceso',
	'UserAddtoProject' => 'Te han relacionado a un proyecto',
	'UserAddtoCompany' => 'Has sido relacionado con una nueva empresa',
	'NewAccountRegistration' => 'Bienvenido a Celestic',
	'newDocumentUpload' => 'New document was uploaded',
	'overdueMilestone' => 'Hito con tareas vencidas',
	'InvoiceCreated' => 'Factura Creada',
	'BudgetCreated' => 'Presupuesto Creado',
	'ExpenseCreated' => 'Gasto Creado',
	'MilestoneAssigned' => 'Hito Asignado',
);
?>