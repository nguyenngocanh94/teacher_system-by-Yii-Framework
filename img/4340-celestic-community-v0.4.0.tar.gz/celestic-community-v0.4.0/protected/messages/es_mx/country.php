<?php
return array(
	// MODEL
	'country_id' => 'Pa&iacute;s',
	'country_name' => 'Nombre del Pa&iacute;s',
	'country_continent' => 'Continente',
	'country_region' => 'Regi&oacute;n',
);
?>