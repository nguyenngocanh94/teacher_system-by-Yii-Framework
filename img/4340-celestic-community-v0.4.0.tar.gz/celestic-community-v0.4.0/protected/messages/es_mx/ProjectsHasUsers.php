<?php
return array(
	'project_id' => 'Proyecto',
	'user_id' => 'Usuarios',
	'client_id' => 'Clientes',
);
?>