<?php
return array(
	// VIEWS
	'TitleExpenseConcepts' => 'Concepto de Gasto',
	// FIELDS
	'FieldCreate' => 'Crear Concepto',
	'FieldUpdate' => 'Actualizar Concepto',
	'FieldList' => 'Listar Conceptos',
	// FORMS
	'FormExpensesConcept_quantity' => 'Escriba la cantidad del producto',
	'FormExpensesConcept_amount' => 'Escriba el valor del producto',
	'FormExpensesConcept_description' => 'Escriba una descripci&oacute;n sobre el producto',
	// MODEL
	'FieldConceptId' => 'Concepto',
	'FieldQuantity' => 'Cantidad',
	'FieldDescription' => 'Descripcion',
	'FieldAmount' => 'Monto',
	'FieldIdExpenses' => 'Gastos',
);
?>