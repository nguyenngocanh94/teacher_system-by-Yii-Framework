<?php
return array(
	// MODEL
	'name' => 'Nombre',
	'type' => 'Tipo',
	'description' => 'Descripci&oacute;n',
	'bizrule' => 'Bizrule',
	'data' => 'Datos',
	'account_id' => 'Cuenta',
	// FIELDS
	'createRoles' => 'Crear nuevo Rol',
	'FieldsRequired' => '<p class="note stick">Campos marcados con <span class="required">*</span> son requeridos.</p>',
	'userList' => 'Lista de Usuarios',
	'appRoles' => 'Roles definidos',
	'pleaseSelectUsertoViewRol' => 'Seleccione un usuario para ver sus roles',
	'pleaseSelectRoletoViewTask' => 'Seleccione un rol para ver sus tareas',
	'roles' => 'Roles',
	'modules' => 'M&oacute;dulos',
	//
	'viewBudgets' => 'assss',
);
?>