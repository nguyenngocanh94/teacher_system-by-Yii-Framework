<?php
return array(
	'analysis' => 'Analysis',
	'design' => 'Design',
	'development' => 'Development',
	'testing' => 'Testing',
	'documentation' => 'Documentation',
	'evolution' => 'Evolution',
	'finalization' => 'Finalization',
);
?>