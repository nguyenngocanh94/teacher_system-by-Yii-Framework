<?php
return array(
	// VIEWS
	'CalendarTitle' => 'Calendar Events',
	'UpcomingMilestonesTitle' => 'Upcoming Milestones',
	'ProjectsProgressTitle' => 'Projects Progress',
	'OverdueMilestonesTitle' => 'Overdue Milestones',
	'MyProjectsTitle' => 'My Projects',
	'RecentActivityTitle' => 'Recent Activity',
	'TasksToDoTitle' => 'Task ToDo',
	'InvoicesStatisticsTitle' => 'Invoices Statistics',
	'HelpResourcesTitle' => 'Tasks Status',
	'EmailNotificationsTitle' => 'Email Notifications',
	'RecentDocumentsTitle' => 'Recent Documents',
	'EffortDistribution' => 'Effort Distribution',
	'ViewAll' => 'View All',
);
?>