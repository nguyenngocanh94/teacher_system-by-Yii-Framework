<?php
return array(
	// MODEL
	'city_id' => 'City',
	'city_name' => 'City Name',
	'city_code' => 'City Code',
	'city_district' => 'City District',
	'city_population' => 'City Population',
	'country_id' => 'Country',
);
?>