<?php
return array(
	'CommentPosted' => 'Comment Posted',
	'BudgetStatusChange' => 'Budget Status Change',
	'BudgetValidationRequest' => 'Budget validation request',
	'CaseStatusChange' => 'Case Status Change',
	'TaskAssigned' => 'Task Assigned',
	'TaskStatusChanged' => 'Task Status Changed',
	'UserInvitation' => 'Invitation to participate in Celestic',
	'PasswordReset' => 'Password Reset Notification',
	'UserAddtoProject' => 'Ready to work with new project',
	'UserAddtoCompany' => 'You\'ve been linked with a new company',
	'NewAccountRegistration' => 'Welcome to Celestic',
	'newDocumentUpload' => 'Un nuevo documento fue subido',
	'overdueMilestone' => 'Milestone with overdue tasks',
	'InvoiceCreated' => 'Invoices Created',
	'BudgetCreated' => 'Budget Created',
	'ExpenseCreated' => 'Expense Created',
	'S' => 'Milestone Assigned',
);
?>