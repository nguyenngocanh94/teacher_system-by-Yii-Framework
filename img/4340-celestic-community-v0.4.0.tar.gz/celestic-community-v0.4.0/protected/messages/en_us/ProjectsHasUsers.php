<?php
return array(
	'project_id' => 'Project',
	'user_id' => 'Users',
	'client_id' => 'Clients',
);
?>