<?php
return array(
	'Suggestion' => 'Suggestion',
	'Error' => 'Error',
	'Addition' => 'Addition',
	'Maintenance' => 'Maintenance',
	'Improvement' => 'Improvement',
	'Modification' => 'Modification',
	'Planning' => 'Planning',
	'Testing' => 'Testing',
);
?>