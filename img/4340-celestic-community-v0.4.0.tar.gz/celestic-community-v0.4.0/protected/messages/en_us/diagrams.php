<?php
return array(
	// FORMS
	'TitleDiagram' => 'Diagram',
	// FIELDS
	'FieldCreateDiagram' => 'Create',
);
?>