<?php
return array(
	// MODEL
	'country_id' => 'Country',
	'country_name' => 'Country Name',
	'country_continent' => 'Country Continent',
	'country_region' => 'Country Region',
);
?>