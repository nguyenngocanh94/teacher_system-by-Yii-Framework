<?php
return array(
	'pending' => 'Pending',
	'revised' => 'To Review',
	'cancelled' => 'Cancelled',
	'accepted' => 'Accepted',
	'closed' => 'Closed',
	'totest' => 'To Test',
	'inprogress' => 'In Progress',
);
?>