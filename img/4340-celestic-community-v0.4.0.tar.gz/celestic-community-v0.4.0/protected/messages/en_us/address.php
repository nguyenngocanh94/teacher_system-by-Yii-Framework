<?php
return array(
	// MODEL
	'address_id' => 'Address',
	'address_text' => 'Postal Address',
	'address_postalCode' => 'Postal Code',
	'address_phone' => 'Address Phone',
	'address_web' => 'Website',
	'city_id' => 'City',
	// FORMS
	'FormAddressText' => 'Set the postal address',
	'FormAddressPostalCode' => 'Set the address postal code',
	'FormAddressPhone' => 'Address phone number',
	'FormAddressWeb' => 'URL if have',
	'FormAddressCity' => 'City where user live',
	'FormDragMark' => 'Drag mark to place address ubication',
	// FIELDS
	'selectOption' => 'Select an Option',
);
?>