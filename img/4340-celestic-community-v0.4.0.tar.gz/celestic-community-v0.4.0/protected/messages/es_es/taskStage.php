<?php
return array(
	'analysis' => 'Analisis',
	'design' => 'Diseno',
	'development' => 'Desarrollo',
	'testing' => 'Pruebas',
	'documentation' => 'Documentacion',
	'evolution' => 'Progreso',
	'finalization' => 'Finalizacion',
);
?>