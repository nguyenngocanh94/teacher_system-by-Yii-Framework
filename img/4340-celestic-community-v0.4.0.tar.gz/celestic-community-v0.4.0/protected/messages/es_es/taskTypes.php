<?php
return array(
	'Suggestion' => 'Sugerencia',
	'Error' => 'Error',
	'Addition' => 'Anexo',
	'Maintenance' => 'Mantenimiento',
	'Improvement' => 'Mejora',
	'Modification' => 'Modificacion',
	'Planning' => 'Planeacion',
	'Testing' => 'Pruebas',
);
?>