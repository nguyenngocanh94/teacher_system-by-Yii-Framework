<?php
return array(
	// MODEL
	'address_id' => 'Direcci&oacute;n',
	'address_text' => 'Direcci&oacute;n Postal',
	'address_postalCode' => 'C&oacute;digo Postal',
	'address_phone' => 'N&uacute;mero Telef&oacute;nico',
	'address_web' => 'Direcci&oacute;n URL',
	'city_id' => 'Ciudad',
	// FORMS
	'FormAddressText' => 'Escriba la direcci&oacute;n postal',
	'FormAddressPostalCode' => 'Escriba el c&oacute;digo postal',
	'FormAddressPhone' => 'Escriba el n&uacute;mero de tel&eacute;fono',
	'FormAddressWeb' => 'URL si tiene',
	'FormAddressCity' => 'Ciudad donde vive el cliente',
	'FormDragMark' => 'Arrastre la marca para establecer la ubicaci&oacute;n',
	// FIELDS
	'selectOption' => 'Seleccione una opci&oacute;n',
);
?>