<?php
return array(
	// VIEWS
	'TitleValidations' => 'Valida&ccedil;&otilde;es',
	'CreateValidations' => 'Criar Valida&ccedil;&atilde;o',
	'UpdateValidations' => 'Atualizar Valida&ccedil;&atilde;o',
	'FieldsRequired' => '<p class="note stick">Campos com <span class="required">*</span> s&atilde;o obrigat&oacute;rios.</p>',
	// MODEL
	'validation_id' => 'Valida&ccedil;&atilde;o',
	'validation_field' => 'Campo',
	'validation_description' => 'Descri&ccedil;&atilde;o',
	'case_id' => 'Caso',
	// FORMS
	'FormValidationField' => 'Campo de formul&aacute;rio relacionado',
	'FormValidationDescription' => 'Descri&ccedil;&atilde;o necess&aacute;ria para completar a valida&ccedil;&atilde;o',
	'FormValidationCase' => 'Caso',
	// FIELDS
	'selectOption' => 'Selecione uma op&ccedil;&atilde;o',
);
?>