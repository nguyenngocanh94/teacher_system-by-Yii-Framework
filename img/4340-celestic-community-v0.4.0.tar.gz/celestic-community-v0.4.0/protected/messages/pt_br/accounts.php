<?php
return array(
	// MODEL
	'account_id' => 'Conta',
	'account_name' => 'Nome da conta',
	'account_logo' => 'Logo',
	'account_colorscheme' => 'Esquema de cor',
	'account_companyName' => 'Nome da empresa',
	'account_projectNumbers' => 'N&uacute;mero de projetos',	
	'account_storageSize' => 'Tamanho em disco',
	'account_uniqueId' => 'Identificador �nico',
	'address_id' => 'Endere�o',
	'timezone_id'=>'Timezone',
	// FORMS
	'FormAccount_colorscheme' => 'Ainda n&atilde;o implementado',
	'FormAccount_logo' => 'Selecione uma imagem para fazer upload',
	'FormAccount_companyName' => 'Defina o nome da sua empresa(usado para faturas)',
	'FormAccount_uniqueId' => 'Identificador �nico como RFC',
	// FIELDS
	'selectOption' => 'Selecione uma op&ccedil;&atilde;o',
	'NewAccountRegistration' => 'Cadastro de Nova Conta',
	'updateAccount' => 'Atualizar Conta',
	
);
?>