<?php
return array(
	'project_id' => 'Projeto',
	'user_id' => 'Usu&aacute;rios',
	'client_id' => 'Clientes',
);
?>