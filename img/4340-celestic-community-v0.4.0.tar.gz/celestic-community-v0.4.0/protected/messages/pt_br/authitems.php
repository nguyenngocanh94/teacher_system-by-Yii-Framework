<?php
return array(
	// MODEL
	'name' => 'Nome',
	'type' => 'Tipo',
	'description' => 'Descri&ccedil;&atilde;o',
	'bizrule' => 'Bizrule',
	'data' => 'Dados',
	'account_id' => 'Conta',
	// FIELDS
	'createRoles' => 'Criar Novo Papel',
	'FieldsRequired' => '<p class="note stick">Campos marcados com <span class="required">*</span> s&atilde;o obrigat&oacute;rios.</p>',
	'userList' => 'Lista de Usu&aacute;rios',
	'appRoles' => 'Pap&eacute;is Definidos',
	'pleaseSelectUsertoViewRol' => 'Selecione um usu&aacute;rio para ver seus pap&eacute;is',
	'pleaseSelectRoletoViewTask' => 'Selecione um papel para ver suas tarefas',
	'roles' => 'Pap&eacute;is',
	'modules' => 'M&oacute;dulos',
);
?>