<?php
return array(
	'pending' => 'Pendente',
	'revised' => 'Por Revisar',
	'cancelled' => 'Cancelar',
	'accepted' => 'Aceito',
	'closed' => 'Fechado',
	'totest' => 'Por Testar',
	'inprogress' => 'Em Progresso',
);
?>