<?php
return array(
	'analysis' => 'An&aacute;lise',
	'design' => 'Design',
	'development' => 'Desenvolvimento',
	'testing' => 'Testes',
	'documentation' => 'Documenta&ccedil;&atilde;o',
	'evolution' => 'Evolu&ceedil;&atilde;o',
	'finalization' => 'Finaliza&ccedil;&atilde;o',
);
?>