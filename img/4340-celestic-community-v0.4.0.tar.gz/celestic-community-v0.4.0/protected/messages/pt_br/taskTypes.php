<?php
return array(
	'Suggestion' => 'Sugest&atilde;o',
	'Error' => 'Erro',
	'Addition' => 'Adi&ccedil;&atilde;o',
	'Maintenance' => 'Manuten&ccedil;&atilde;o',
	'Improvement' => 'Melhoria',
	'Modification' => 'Modifica&ccedil;&atilde;o',
	'Planning' => 'Planejamento',
	'Testing' => 'Testes',
);
?>