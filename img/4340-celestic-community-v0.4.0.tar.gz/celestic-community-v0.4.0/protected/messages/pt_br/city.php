<?php
return array(
	// MODEL
	'city_id' => 'Cidade',
	'city_name' => 'Nome da Cidade',
	'city_code' => 'C&oacute;digo da Cidade',
	'city_district' => 'Distrito',
	'city_population' => 'Popula&ccedil;&atilde;o',
	'country_id' => 'Pa&iacute;s',
);
?>