<?php
return array(
	'CommentPosted' => 'Coment&aacute;rio escrito',
	'BudgetStatusChange' => 'Mudan&ccedil;a de status de or&ccedil;amento',
	'BudgetValidationRequest' => 'Pedido de valida&ccedil;&atilde;o de or&ccedil;amento',
	'CaseStatusChange' => 'Mudan&ccedil;a de status em caso',
	'TaskAssigned' => 'Atribui&ccedil;&atilde;o de tarefa',
	'TaskStatusChanged' => 'Mudan&ccedil;a de status de tarefa',
	'UserInvitation' => 'Convite para participar do Celestic',
	'PasswordReset' => 'Notifica&ccedil;&atilde;o de mudan&ccedil;a de senha',
	'UserAddtoProject' => 'Voc&ecirc; foi relacionado a um projeto',
	'UserAddtoCompany' => 'Voc&ecirc; foi relacionado a uma nova empresa',
	'NewAccountRegistration' => 'Bemvindo a Celestic',
	'newDocumentUpload' => 'Novo documento foi carregado',
	'overdueMilestone' => 'Etapa com tarefas vencidas',
	'InvoiceCreated' => 'Fatura Criada',
	'BudgetCreated' => 'Or&ccedil;amento Criado',
	'ExpenseCreated' => 'Gasto Criado',
	'MilestoneAssigned' => 'Etapa Atribu&iacute;da',
);
?>