<?php
return array(
	// MODEL
	'address_id' => 'Endere&ccedil;o',
	'address_text' => 'Endere&ccedil;o Postal',
	'address_postalCode' => 'C&oacute;digo Postal do Endere&ccedil;o',
	'address_phone' => 'Telefone do Endere&ccedil;o',
	'address_web' => 'Website',
	'city_id' => 'Cidade',
	// FORMS
	'FormAddressText' => 'Definir o endere�o postal',
	'FormAddressPostalCode' => 'Definir o c&oacute;digo postal do endere&ccedil;o',
	'FormAddressPhone' => 'Telefone do endere&ccedil;o',
	'FormAddressWeb' => 'URL se tiver',
	'FormAddressCity' => 'Cidade onde o usu&aacute;rio vive',
	'FormDragMark' => 'Arraste a marca para definir localiza&ccedil;&atilde;o do endere&ccedil;o',
	// FIELDS
	'selectOption' => 'Selecione uma op&ccedil;&atilde;o',
);
?>