<?php
return array(
	// VIEWS
	'CommentsTitle' => 'Coment&aacute;rios',
	'AttachFiles' => 'Adicionar arquivos desde aqui',
	'FileAlready' => 'O arquivo selecionado j&aacute; foi adicionado',
	'Attachments' => 'Arquivos anexos',
	'DownloadFile' => 'Baixar arquivo',
	'UploadOk' => 'carregado com sucesso :)',
	'UploadError' => 'n&atilde;o pode ser carregado',
	'UploadCheckErrors' => 'verifique os seguintes erros',
	'RequiredComment' => 'O coment&aacute;rio &eacute; obrigat&oacute;rio',
	// MODEL
	'Comment' => 'Coment&aacute;rio',
	'Date' => 'Data de cria&ccedil;&atilde;o',
	'Text' => 'Deixe sua mensagem',
	'Resource' => 'Fonte',
	'User' => 'Coment&aacute;rio criado por',
	'Module' => 'M&oacute;dulo',
	// FIELDS
	'OkButton' => 'Salvar',
	'CancelButton'=> 'Cancelar',
	'EditTooltip'=> 'Clique duas vezes para editar coment&aacute;rio',
	'HoldMessage'=> 'Salvando...',
);
?>