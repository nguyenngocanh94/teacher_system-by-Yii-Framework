<?php
return array(
	// VIEWS
	'CalendarTitle' => 'Calend&aacute;rio de Eventos',
	'UpcomingMilestonesTitle' => 'Etapas Pr&oacute;ximas',
	'ProjectsProgressTitle' => 'Progresso de Projetos',
	'OverdueMilestonesTitle' => 'Etapas Atrasadas',
	'MyProjectsTitle' => 'Meus Projetos',
	'RecentActivityTitle' => 'Atividade Recente',
	'TasksToDoTitle' => 'Tarefas a fazer',
	'InvoicesStatisticsTitle' => 'Fatura&ccedil;&atilde;o',
	'HelpResourcesTitle' => 'Status de tarefas',
	'EmailNotificationsTitle' => 'Notifica&ccedil;&otilde;es',
	'RecentDocumentsTitle' => 'Documentos Recentes',
	'EffortDistribution' => 'Distribui&ccedil;&atilde;o de Esfor&ccedil;o',
	'ViewAll' => 'Ver Todos',
);
?>