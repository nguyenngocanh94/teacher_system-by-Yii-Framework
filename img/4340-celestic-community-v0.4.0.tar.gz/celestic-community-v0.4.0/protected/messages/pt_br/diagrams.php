<?php
return array(
	// FORMS
	'TitleDiagram' => 'Diagramas',
	// FIELDS
	'FieldCreateDiagram' => 'Criar',
);
?>